export enum TransactionStatus {
    PENDING = 'PENDING',
    PAID = 'PAID',
}