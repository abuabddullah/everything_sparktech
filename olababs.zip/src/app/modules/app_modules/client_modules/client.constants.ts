export const ClientSearchableFields = [
    'firstName',
    'lastName',
    'email',
    'phone',
];