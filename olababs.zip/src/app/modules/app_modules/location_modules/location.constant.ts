export const LocationSearchableFields= [
  'location',
  'address',
  'city',
  'state',
  'country',
  'zipCode',
];