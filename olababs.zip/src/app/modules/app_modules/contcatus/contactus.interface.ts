export type TContact = {
     name: string;
     email: string;
     subject: string;
     message: string;
};
