export type ISendEmail = {
  to: string | undefined;
  subject: string | undefined;
  html: string | undefined;
};
