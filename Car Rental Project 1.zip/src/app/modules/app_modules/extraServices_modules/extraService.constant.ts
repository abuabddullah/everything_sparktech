export const ExtraServiceSearchableFields = [
    'name',
    'description',
];