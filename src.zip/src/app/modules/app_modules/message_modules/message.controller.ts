import { Request, Response } from 'express';
import catchAsync from '../../../../shared/catchAsync';
import { MessageService } from './message.service';
import sendResponse from '../../../../shared/sendResponse';
import { StatusCodes } from 'http-status-codes';

const sendMessage = catchAsync(async (req: Request, res: Response) => {
  const user = req.user.id;


  let image;
  if (req.files && "image" in req.files && req.files.image[0]) {
    image = `/images/${req.files.image[0].filename}`;
  }

  const payload = {
    ...req.body, // chatId,text
    image: image,
    sender: user,
  };

  const message = await MessageService.sendMessage(payload);
  sendResponse(res, {
    statusCode: StatusCodes.OK,
    success: true,
    message: 'Send Message Successfully',
    data: message,
  });
});

const getMessageByChatID = catchAsync(async (req: Request, res: Response) => {
  const id = req.params.id;
  const messages = await MessageService.getMessageByChatIDFromDB(id);
  sendResponse(res, {
    statusCode: StatusCodes.OK,
    success: true,
    message: 'Message Retrieve Successfully',
    data: messages,
  });
});

export const MessageController = { sendMessage, getMessageByChatID };