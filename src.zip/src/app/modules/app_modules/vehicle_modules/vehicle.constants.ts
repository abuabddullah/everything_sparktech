export const VehicleSearchableFields = [
    'name',
    'brand',
    'model',
    'licenseNumber',
    'vehicleType',
];